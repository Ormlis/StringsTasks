#!/usr/bin/env bash
#   *** validation ***
scripts/run-validator-tests.sh
scripts/run-checker-tests.sh

#    *** tests ***
mkdir -p tests
echo "Generating test #1"
scripts/gen-input-via-stdout.sh "wine files/gen.exe mode=anime" "tests/01" 1
echo "Generating test #2"
scripts/gen-input-via-stdout.sh "wine files/gen.exe shuffle mode=random n=10 slen=50 T mode=pal n=10 slen=33 alen=15 T mode=random n=50 slen=50 alph=4 T shuffle mode=random n=1 slen=250 T shuffle mode=thue slen=228 alen=45 alph=3 T mode=pal n=20 slen=279 alen=341" "tests/02" 2
echo "Generating test #3"
scripts/gen-input-via-stdout.sh "wine files/gen.exe mode=pal n=45 slen=551 alen=228 T mode=pal n=100 slen=523 alen=505 T mode=pal n=100 slen=644 alen=710 T mode=pal n=100 slen=1240 alen=2604 T mode=pal n=50 slen=1894 alen=975 T shuffle mode=random n=1000 slen=5000 T shuffle mode=random n=2500 slen=6000 alph=3 T mode=pal n=3000 slen=5231 alen=5604 T mode=pal n=5000 slen=10438 alen=15023 T mode=random n=13000 slen=13000 alph=3 T shuffle mode=random n=1 slen=200000 alph=2 T shuffle mode=thue slen=55031 alen=45028 alph=3 T mode=pal n=3000 slen=50231 alen=44596 alph=4 T mode=pal n=10000 slen=89249 alen=67645 alph=3" "tests/03" 3
echo ""
echo "Generating answer for test #1"
scripts/gen-answer.sh tests/01 tests/01.a "tests" ""
echo ""
echo "Generating answer for test #2"
scripts/gen-answer.sh tests/02 tests/02.a "tests" ""
echo ""
echo "Generating answer for test #3"
scripts/gen-answer.sh tests/03 tests/03.a "tests" ""
echo ""

