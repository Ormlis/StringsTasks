#!/usr/bin/env bash
#   *** tests ***
rm -f tests/01
rm -f tests/01.a
rm -f tests/02
rm -f tests/02.a
rm -f tests/03
rm -f tests/03.a

