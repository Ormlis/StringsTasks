#!/usr/bin/env bash
echo "Running 0 checker test(s)"
echo "Running 0 checker test(s)" 1> checker-tests.log
rm -f checker-tests.log
echo "Checker test(s) finished"
